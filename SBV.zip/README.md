# Dashboard Phân Tích Báo Cáo Tài Chính - Ngân Hàng BIDV

Dự án này là một Web Dashboard sử dụng **Streamlit** và **Plotly** để đọc và trực quan hóa dữ liệu từ báo cáo tài chính (BCTC) của Ngân hàng TMCP Đầu tư và Phát triển Việt Nam (BIDV) dựa trên file dữ liệu Excel.

## Các chức năng chính
- Lọc dữ liệu theo mốc thời gian (Năm).
- Hiển thị bảng số liệu gốc trực quan.
- Biểu đồ biến động Tổng Tài sản, Nợ phải trả và Vốn chủ sở hữu.
- Biểu đồ cột thể hiện mức dư nợ Cho vay và Tiền gửi.
- Biểu đồ vùng cho hoạt động Đầu tư & Chứng khoán.

## Cài đặt và Chạy thiết lập ở Local
1. Cài đặt các thư viện yêu cầu:
   ```bash
   pip install -r requirements.txt
   ```
2. Chạy ứng dụng web:
   ```bash
   streamlit run app.py
   ```

## Môi trường Triển khai (Deployment)
Dự án này đã thiết lập sẵn toàn bộ tính năng và cấu hình giao diện `light-mode` (`.streamlit/config.toml`), hoàn toàn tương thích và sẵn sàng đẩy lên **Streamlit Community Cloud**.
